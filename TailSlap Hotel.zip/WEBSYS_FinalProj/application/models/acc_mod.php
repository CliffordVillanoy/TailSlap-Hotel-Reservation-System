<?php

class Acc_mod extends CI_Model
{
    public function fetch()
    {
        $query = $this->db->order_by('GuestID', 'DESC')->get('tblguest')->result();
        return $query;
    }

    public function fetch_bookings($user_id)
    {
        $query = $this->db->where('GuestID', $user_id)->get('tblguest')->result();
        return $query;
    }

    
    public function fetch_room($roomnumber)
    {
        $query = $this->db->where('Roomnumber', $roomnumber)->get('tblbooking')->result();
        return $query;
    }
    

    public function acc_bookings($user_id)
    {
        $query = $this->db->order_by('Roomnumber', 'ASC')->where('GuestID', $user_id)->get('tblbooking')->result();
        return $query;
    }


    public function show_row($user_id)
    {
        $query = $this->db->where('GuestID', $user_id)->get('tblbooking')->num_rows();
        return $query;
    }



    public function fetch_users($user_id)
    {
        $query = $this->db->where('GuestID', $user_id)->get('tblguest')->result();
        return $query;
    }
    public function update_room($currentroomnum,$user_id,$capsule,$oldtransactionid)
    {
        $query = $this->db->where('Roomnumber', $currentroomnum)->update('tblbooking',$capsule);
        return $query;
    }

    public function save($capsule,$user_id)
    {
        $insert=$this->db->where('GuestID', $user_id)->update('tblguest', $capsule);
        if ($insert){
            return $msg = "Data inserted successfully";
        }
    }

    public function changepass($user_email, $capsule)
    {
        $query=$this->db->where('Email', $user_email)->update('tblguest', $capsule);
        if($query){$this->session->set_userdata(array('acc_pass'=>True));}

    }

    public function show_row_acc($user_email)
    {
        $query = $this->db->where('Email', $user_email)->get('tblguest')->result();
        return $query;
        if($query){$this->session->set_userdata(array('usr_email'=>True));}
        else $this->session->set_userdata(array('usr_email'=>False));

    }
}
