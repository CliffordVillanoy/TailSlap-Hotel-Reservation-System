<?php

class admin_mod extends CI_Model
{

    public function get_data()
    {
        $query = $this->db->get('tblbooking')->result();
        return $query;
    }

    public function update_bookings ($status,$Roomnumber,$capsule)
    {
        if($status == 'Declined')
        {
            $query= $this->db->where('Roomnumber',$Roomnumber)->where('Stats','PENDING')->delete('tblbooking');
            if($query)
            {
                //echo "data deleted successfully";
                $this->session->set_userdata(array('update'=>true));
                redirect('Admin/dashboard');
                
            }else echo "error";
        }

        if($status == 'Accepted')
        {
            $query= $this->db->where('Stats','PENDING')->where('Roomnumber',$Roomnumber)->update('tblbooking',$capsule);
            if($query)
            {
                $this->session->set_userdata(array('update'=>true));

                redirect('Admin/dashboard');

            }else echo "error";
        }
    }

}?>
