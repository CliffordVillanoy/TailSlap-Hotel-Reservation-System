<?php

class RoomCheck_mod extends CI_Model{


    public function check_room($roomnumber)
    {
        $query=$this->db->where('Roomnumber',$roomnumber)->get('tblbooking')->result();
        return $query;
    }
    public function check_rows($roomnumber)
    {
        $query=$this->db->where('Roomnumber',$roomnumber)->get('tblbooking')->num_rows();
        return $query;
    }
    

}?>