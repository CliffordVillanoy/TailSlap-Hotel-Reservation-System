<?php

class Signup_mod extends CI_Model
{
    public function insert_data($capsule)
    {
        $inesert=$this->db->insert('tblguest',$capsule);
        if ($inesert){
            "Data inserted successfully";
        }
    }





}

?>