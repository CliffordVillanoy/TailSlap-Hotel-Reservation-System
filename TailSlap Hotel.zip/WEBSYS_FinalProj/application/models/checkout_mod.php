<?php

class Checkout_mod extends CI_Model{


    public function checkout($roomnumber)
    {
        $query=$this->db->where('Roomnumber',$roomnumber)->delete('tblbooking');
        return $query;
    }


}?>