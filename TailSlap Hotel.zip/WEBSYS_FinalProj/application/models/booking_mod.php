<?php

class Booking_mod extends CI_Model{

    public function check_room($roomNo)
    {
        $query = $this->db->where('Roomnumber', $roomNo)->get('tblbooking')->num_rows();
        return $query;
    }
    public function reservation($details)
    {
        $query = $this->db->insert('tblbooking', $details);
        return $query;
    }

    public function show_reservations($user_id)
    {
        $query = $this->db->where('GuestID', $user_id)->get('tblbooking')->result();
        return $query;
    }

    public function cancel_booking($roomnumber,$roomtype)
    {
        $query = $this->db->where('Roomnumber', $roomnumber)->where('Roomtype', $roomtype)->delete('tblbooking');
    }
    public function check($roomnumber)
    {
        $query = $this->db->where('Roomnumber', $roomnumber)->get('tblbooking')->result();
        return $query;
    }
    

}
?>