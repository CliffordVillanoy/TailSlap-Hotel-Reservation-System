<?php

class Signin_mod extends CI_Model
{
    public function user_check($user_email,$user_pass)
    {
        $query=$this->db->where('Email',$user_email)->where('Password',$user_pass)->get('tblguest');
        return $query->result();
        if($query){}
        else{$this->session->set_userdata(array('account'=>false));}//account doesnt exist
    }
    public function bookings_check($GuestId)
    {
        $query=$this->db->where('GuestID',$GuestId)->get('tblbooking');
        return $query->result();
    }




}

?>