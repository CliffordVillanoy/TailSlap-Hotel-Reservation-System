<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
            content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>TailSlap | Offer</title>
        <!--Font awesome CDN-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
        <!--CSS Link-->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/styles.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/acc.css">
    </head>
    <body>

         <!--Start of Hamburger menu-->
        <header class="header">
            <div class="container">
                <nav class="nav">
                    <a href="<?php echo base_url('index.php/Homepage/home');?>" class="logo">
                    <?php echo img('assets/images/hotelname.png'); ?>
                    </a>
                    <div class="hamburger-menu">
                        <i class="fas fa-bars"></i>
                        <i class="fas fa-times"></i>
                    </div>
                    <!--End of Hamburger menu-->

                    <!--Start of Navigation Menu-->
                    <ul class="nav-list">

                        <li class="nav-item">
                        <a href="<?php echo base_url('index.php/Homepage/home');?>" class="nav-link">Home</a>
                        </li>

                        <li class="nav-item">
                        <a href="<?php echo base_url('index.php/Homepage/about');?>" class="nav-link">About</a>
                        </li>

                        <li class="nav-item">
                        <a href="<?php echo base_url('index.php/Homepage/offer');?>" class="nav-link">Offers</a>
                        </li>
                        
                        <li class="nav-item">
                        <a href="<?php echo base_url('index.php/Homepage/contact');?>" class="nav-link">Contact</a>
                        </li>
                        <li class="nav-item">
                        <?php if( $this->session->userdata('loggedIn') ): ?>
                            <a href="<?php echo base_url('index.php/Account/show_account');?>" class="nav-link">Account</a>
                        <?php else: ?>
                            <a href="<?php echo base_url('index.php/Homepage/contact');?>" class="nav-link">Login</a>
                        <?php endif; ?>
                    </li>

                    </ul>
                </nav>
            </div>
        </header>
        <!--End of Navigation Menu-->
        <br><br><br><br><br><br><br><br>

         <!--Start of discounts and offers-->
         <section class="offer">
            <div class="container">
                <div class="offer-content">
                    <div class="discount">
                        20% discount
                    </div>
                    <h5 class="hotel-name">The Paradise</h5>
                    <div class="hotel-rating">
                        <i class="fas fa-star rating"></i>
                        <i class="fas fa-star rating"></i>
                        <i class="fas fa-star rating"></i>
                        <i class="fas fa-star rating"></i>
                        <i class="fas fa-star-half rating"></i>
                    </div>
                    <p class="paragraph">
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
                        when an unknown printer took a galley of type and scrambled it to make a type 
                        specimen book. It has survived not only five centuries, but also the leap into 
                        electronic typesetting, remaining essentially unchanged.
                    </p>
                    <a href="<?php echo base_url('index.php/Homepage/explore_room');?>" class="btn btn-gradient"> Avail now
                        <span class="dots"><i class="fas fa-ellipsis-h"></i></span>
                    </a>
                </div>
            </div>
        </section>
        <!--End of discounts and offers-->





        <br><br><br>
        <!--Start of the footer-->
        <footer class="footer">
            <!--Start of the footer container-->
            <div class="container">
                <!--Start of the footer-content-->
                <div class="footer-content">

                    <div class="footer-content-brand">
                        <a href="<?php echo base_url('index.php/Homepage/home');?>" class="logo">
                            <img class="logo-image" src="<?php echo base_url(); ?>assets/images/hotellogo.png" alt="logo">
                        </a>
                        <div class="paragraph">
                            Lorem, ipsum dolor sit amet consectetur adipisicing 
                            elit. Porro reiciendis, quas sint eius omnis dicta 
                            molestias temporibus tenetur hic labore atque aliquid 
                            natus quasi ad, quae dolorem. Ipsum, magnam at.
                        </div>
                    </div>

                    <!--Start of social media icons-->
                    <div class="social-media-wrap">
                        <h4 class="footer-heading">Follow Us</h4>
                        <div class="social-media">
                            <a href="#" class="sm-link"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="sm-link"><i class="fab fa-facebook-square"></i></a>
                            <a href="#" class="sm-link"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                    <!--End of social media icons-->

                </div>
                <!--End of the footer-content-->
            </div>
            <!--End of the footer container-->
        </footer>
        <!--End of the footer-->
    </body>
</html>