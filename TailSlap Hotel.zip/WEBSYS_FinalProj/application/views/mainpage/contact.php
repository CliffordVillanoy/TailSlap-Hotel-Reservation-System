<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
            content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>TailSlap | Contact</title>
        <!--Font awesome CDN-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
        <!--CSS Link-->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/styles.css">
    </head>
    <body>

         <!--Start of Hamburger menu-->
        <header class="header">
            <div class="container">
                <nav class="nav">
                    <a href="<?php echo base_url(); ?>index.php/Hompage/home" class="logo">
                        <img src="<?php echo base_url(); ?>assets/images/hotelname.png" alt="">
                    </a>
                    <div class="hamburger-menu">
                        <i class="fas fa-bars"></i>
                        <i class="fas fa-times"></i>
                    </div>
                    <!--End of Hamburger menu-->

                    <!--Start of Navigation Menu-->
                    <ul class="nav-list">

                    <li class="nav-item">
                        <a href="<?php echo base_url('index.php');?>" class="nav-link">Home</a>
                        </li>

                        <li class="nav-item">
                        <a href="<?php echo base_url('index.php/Homepage/about');?>" class="nav-link">About</a>
                        </li>

                        <li class="nav-item">
                        <a href="<?php echo base_url('index.php/Homepage/offer');?>" class="nav-link">Offers</a>
                        </li>
                        
                        <li class="nav-item">
                        <a href="<?php echo base_url('index.php/Homepage/contact');?>" class="nav-link">Contact</a>
                        </li>

                        <li class="nav-item">
                        <?php if( $this->session->userdata('loggedIn') ): ?>
                            <a href="<?php echo base_url('index.php/Account/show_account');?>" class="nav-link">Account</a>
                        <?php else: ?>
                            <a href="<?php echo base_url('index.php/Homepage/login');?>" class="nav-link">Login</a>
                        <?php endif; ?>
                        </li>
                    </ul>
                </nav>
            </div>
        </header>
        <!--End of Navigation Menu-->
        <br><br>

        <section class="contact">

            <!--Start of div container-->
            <div class="container">
                <h5 class="section-head">
                    <span class="heading">Contact Us</span>
                    <span class="sub-heading">Just leave us a message</span>
                </h5>
                <!--Start of div contact-content-->
                <div class="contact-content">
                    <div class="traveler-wrap">
                    <?php echo img('assets/images/contact.png'); ?>
                    </div>

                    <!--Start of the form-->
                    <form action="resources/libraries/contact_us.php" method="POST" class="form contact-form">
                        <div class="input-group-wrap">

                            <!--Name-->
                            <div class="input-group">
                                <input type="text" class="input" name="fullname" placeholder="Name" required>
                                <span class="bar"></span> 
                            </div>

                            <!--Email-->
                            <div class="input-group">
                                <input type="email" class="input" name="email" placeholder="E-Mail" required>
                                <span class="bar"></span> 
                            </div>
                        </div>

                            <!--Subject-->
                            <div class="input-group">
                                <input type="text" class="input" name="subject" placeholder="Subject" required>
                                <span class="bar"></span> 
                            </div>

                            <!--Text area-->
                            <div class="input-group">
                                <textarea class="input" cols="30" name="message" rows="8"  placeholder="Text area" required></textarea>
                                <span class="bar"></span> 
                            </div>

                            <!--Button for contact form-->
                            <button type="submit" name="btnmessage" class="btn form-btn btn-purple"> Send Message 
                                <span class="dots"><i class="fas fa-ellipsis-h"></i></span>
                            </button>

                    </form>
                    <!--End of the form-->
                </div>
                <!--End of div contact-content-->
            </div>
            <!--End of div container-->

        </section>
         <!--End of Contact form-->








        <br>
        <!--Start of the footer-->
        <footer class="footer">
            <!--Start of the footer container-->
            <div class="container">
                <!--Start of the footer-content-->
                <div class="footer-content">

                    <div class="footer-content-brand">
                        <a href="index.html" class="logo">
                            <img class="logo-image" src="<?php echo base_url(); ?>assets/images/hotellogo.png" alt="logo">
                        </a>
                        <div class="paragraph">
                            Lorem, ipsum dolor sit amet consectetur adipisicing 
                            elit. Porro reiciendis, quas sint eius omnis dicta 
                            molestias temporibus tenetur hic labore atque aliquid 
                            natus quasi ad, quae dolorem. Ipsum, magnam at.
                        </div>
                    </div>

                    <!--Start of social media icons-->
                    <div class="social-media-wrap">
                        <h4 class="footer-heading">Follow Us</h4>
                        <div class="social-media">
                            <a href="#" class="sm-link"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="sm-link"><i class="fab fa-facebook-square"></i></a>
                            <a href="#" class="sm-link"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                    <!--End of social media icons-->

                </div>
                <!--End of the footer-content-->
            </div>
            <!--End of the footer container-->
        </footer>
        <script> //Selectors
let header = document.querySelector('.header');
let hamburgerMenu = document.querySelector('.hamburger-menu');

window.addEventListener('scroll', function(){
    let windowPosition = window.scrollY > 0;
    header.classList.toggle('active', windowPosition)
})

hamburgerMenu.addEventListener('click', function(){
    header.classList.toggle('menu-open');
}) </script>
        <!--End of the footer-->
    </body>
</html>