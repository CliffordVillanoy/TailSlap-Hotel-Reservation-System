<!DOCTYPE html>
<html>

<head>
  <title>TailSlap | Log In</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/styles.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/login.css">

  <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700,800&display=swap" rel="stylesheet">
</head>

<body>
  <!--Start of Hamburger menu-->
  <header class="header">
    <div class="container">
      <nav class="nav">
        <a href="<?php echo base_url('index.php/Homepage/home'); ?>" class="logo">
          <?php echo img('assets/images/hotelname.png'); ?>
        </a>
        <div class="hamburger-menu">
          <i class="fas fa-bars"></i>
          <i class="fas fa-times"></i>
        </div>
        <!--End of Hamburger menu-->

        <!--Start of Navigation Menu-->
        <ul class="nav-list">

          <li class="nav-item">
            <a href="<?php echo base_url('index.php/Homepage/home'); ?>" class="nav-link">Home</a>
          </li>

          <li class="nav-item">
            <a href="<?php echo base_url('index.php/Homepage/about'); ?>" class="nav-link">About</a>
          </li>

          <li class="nav-item">
            <a href="<?php echo base_url('index.php/Homepage/offer'); ?>" class="nav-link">Offers</a>
          </li>

          <li class="nav-item">
            <a href="<?php echo base_url('index.php/Homepage/contact'); ?>" class="nav-link">Contact</a>
          </li>

          <li class="nav-item">
            <a href="<?php echo base_url('index.php/Homepage/login'); ?>" class="nav-link">Login</a>
          </li>

        </ul>
      </nav>
    </div>
  </header>
  <!--End of Navigation Menu-->

  <div class="cont">

    <form action="<?php echo base_url('index.php/libraries/Signin/signin_form'); ?>" method="POST">
      <div class="form sign-in">
        <h2>Log In</h2>
        <label>
          <span>Email Address</span>
          <input id="email" type="text" name="signin_email" value="<?php echo set_value('signin_email'); ?>">
          <p><?php echo form_error('signin_email'); ?></p>
          <p><?php if($this->session->userdata('account') == False) {
                echo $this->session->flashdata('acc');
              }  ?></p>
        </label>
        <label>
          <span>Password</span>
          <input type="password" name="signin_password" value="<?php echo set_value('signin_password'); ?>">
          <p><?php echo form_error('signin_password'); ?></p>

        </label>
        <button class="submit" type="submit" onclick="errorMessage()" name="btnLogin">Log In</button>
    </form>

    <!--Forgot password-->
    <form action="<?php echo base_url('index.php/libraries/forgotpass/changepass_form'); ?>" method="POST">
      <button class="forgot-pass">Forgot Password ?</button>
    </form>
  </div>



  <div class="sub-cont">
    <div class="img">
      <div class="img-text m-up">
        <h2>New here?</h2>
        <p>Sign up and discover great amount of new opportunities!</p>
      </div>
      <div class="img-text m-in">
        <h2>One of us?</h2>
        <p>If you already has an account, just sign in. We've missed you!</p>
      </div>
      <div class="img-btn">
        <span class="m-up">Sign Up</span>
        <span class="m-in">Log In</span>
      </div>
    </div>
    <!-- SIGN UP  -->

    <form action="<?php echo base_url('index.php/libraries/signup/signup_form') ?>" method="POST">
      <div class="form sign-up">
        <h2 style="margin-top: -12px;">Sign Up</h2>
        <span id="error"><?php //if (isset($create_user_form_errors)) echo $create_user_form_errors;  
                          ?></span>
        <label>
          <span>First Name</span>

          <input id="firstname" type="text" name="firstname" value="<?php echo set_value('firstname'); ?>">
          <p><?php echo form_error('firstname'); ?></p>
        </label>
        <label>
          <span>Last Name</span>
          <input id="lastname" type="text" name="lastname" value="<?php echo set_value('lastname'); ?>">
          <p><?php echo form_error('lastname'); ?></p>

        </label>
        <label>
          <span>Email</span>
          <input id="email " type="email" name="email" value="<?php echo set_value('email'); ?>">
          <p><?php echo form_error('email'); ?> </p>
        </label>
        <label>
          <span>Password</span>
          <input id="password " type="password" name="password" value="<?php echo set_value('password'); ?>">
          <p><?php echo form_error('password'); ?></p>

        </label>
        <label>
          <span>Confirm Password</span>
          <input id="confirmpassword " type="password" name="confirmpassword" value="<?php echo set_value('confirmpassword'); ?>">
          <p><?php echo form_error('password'); ?></p>

        </label>
        <button type="submit" name="btnSignup" class="submit" style="margin-bottom: 15px">Sign Up Now</button>
      </div>
    </form>
  </div>
  </div>

  <script>
    document.querySelector('.img-btn').addEventListener('click', function() {
      document.querySelector('.cont').classList.toggle('s-signup')
    });
  </script>
</body>

</html>