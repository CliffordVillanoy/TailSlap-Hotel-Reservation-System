<!Doctype html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
            content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>TailSlap | Explore Room</title>
        <!--Font awesome CDN-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <!--CSS Link-->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/styles.css">

        <style>
            .photo-bg{
                margin: 20px auto;
                margin-top: 150px;
                width: 80%;
                background: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url(assets/images/hero_background.jpg);
                background-position: center;
                background-size: cover;
                border-radius: 15px;
                text-align: center;
                padding: 100px 0;
            }
            .photo-bg h1{
                font-size: 50px;
                color: lightgray;
            }
            .rooms{
                width: 100%;
                display: flex;
                justify-content: center;
                flex-wrap: wrap;
            }
            .card-horizontal {
                display: flex;
                flex: 1 1 auto;
            }
            .card-body {
                padding-left: 5px;
            }
            .btn{
                color: white;
                background-color: #0c8094;
                border: none;
                font-size: 14px;
                font-weight: 600;
                margin: 10px;
            }
            .btn:hover{
                background-color: #035162;
                color: white;
                transition: .8s;
            }
        </style>
    </head>
    <body>
        <!--Start of Hamburger menu-->
        <header class="header">
            <div class="container">
                <nav class="nav">
                    <a href="<?php echo base_url('index.php/Homepage');?>" class="logo">
                    <?php echo img("assets/images/hotelname.png") ?>
                    </a>
                    <div class="hamburger-menu">
                        <i class="fas fa-bars"></i>
                        <i class="fas fa-times"></i>
                    </div>
                    <!--End of Hamburger menu-->

                    <!--Start of Navigation Menu-->
                    <ul class="nav-list">

                    <li class="nav-item">
                        <a href="<?php echo base_url('index.php/Homepage/home');?>" class="nav-link">Home</a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo base_url('index.php/Homepage/about');?>" class="nav-link">About</a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo base_url('index.php/Homepage/offer');?>" class="nav-link">Offers</a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="<?php echo base_url('index.php/Homepage/contact');?>" class="nav-link">Contact</a>
                    </li>
                        <li class="nav-item">
                        <?php if( $this->session->userdata('loggedIn') ): ?>
                            <a href="<?php echo base_url('index.php/Account/show_account');?>" class="nav-link">Account</a>
                        <?php else: ?>
                            <a href="<?php echo base_url('index.php/Homepage/login');?>" class="nav-link">Login</a>
                        <?php endif; ?>
                    </li>
                        

                    </ul>
                </nav>
            </div>
        </header>
        <div class="photo-bg">
			<h1><span>TAILSLAP HOTEL</span></h1>
			<br>
		</div>
        <br><br><Br>
        <!--End of Navigation Menu-->
        <div class="container px-4" >
            <div class="row gx-5">
              <div class="col">

              </div>
              <div class="col">

              </div>
            </div>
            <br><br>
            <div class="row gx-5">
                <div class="col">
                  <div class="card">
                      <div class="card-horizontal">
                          <div class="img-square-wrapper">
                          <?php echo img("assets/images/presidential.png") ?>
                          </div>
                          <div class="card-body">
                            <h3 class="card-title" style="padding:10px;"><b>Presidential Suite</b></h3>
                            <p class="card-text" style="font-size: 16px; padding-left: 13px;">With your Stay:</p>
                            <p class="card-text" style="font-size: 14px; padding-left:15px;">Room Type: PRE</p>
                            <p class="card-text" style="font-size: 14px; padding-left:15px;">Price: ₱ 4,000.00</p>
                            <a href="<?php 
                                if($this->session->userdata('loggedIn')):?>
                                <?php echo base_url('index.php/Rooms/form_pre');?>
                                <?php else:?>
                                    <?php redirect('index.php/Homepage/home');?>
                                <?php endif?>" class="btn btn-primary">BOOK NOW</a>
                          </div>
                      </div>
                  </div>
                </div>
                <div class="col">
                  <div class="card">
                      <div class="card-horizontal">
                          <div class="img-square-wrapper">
                          <?php echo img("assets/images/cabana.png") ?>
                          </div>
                          <div class="card-body">
                                <h3 class="card-title" style="padding:10px;"><b>Cabana</b></h3>
                              <p class="card-text" style="font-size: 16px; padding-left: 13px;">With your Stay:</p>
                              <p class="card-text" style="font-size: 14px; padding-left:15px;">Room Type: CAB</p>
                              <p class="card-text" style="font-size: 14px; padding-left:15px;">Price: ₱ 5,000.00</p>
                            <a href="<?php 
                                if($this->session->userdata('loggedIn')):?>
                                <?php echo base_url('index.php/Rooms/form_cab');?>
                                <?php else:?>
                                    <?php redirect('Homepage/index');?>
                                <?php endif?>" class="btn btn-primary">BOOK NOW</a>
                          </div>
                      </div>
                  </div>
                </div>
              </div>

              
              <br><br>
              
              <div class="row gx-5">
                <div class="col">
                  <div class="card">
                      <div class="card-horizontal">
                          <div class="img-square-wrapper">
                          <?php echo img("assets/images/villa.png") ?>
                          </div>
                          <div class="card-body">
                            <h3 class="card-title" style="padding:10px;"><b>Villa</b></h3>
                            <p class="card-text" style="font-size: 16px; padding-left: 13px;">With your Stay:</p>
                            <p class="card-text" style="font-size: 14px; padding-left:15px;">Room Type: VIL</p>
                            <p class="card-text" style="font-size: 14px; padding-left:15px;">Price: ₱ 6,000.00</p>
                            <a href="<?php 
                                if($this->session->userdata('loggedIn')):?>
                                <?php echo base_url('index.php/Rooms/form_vil');?>
                                <?php else:?>
                                    <?php redirect('Homepage/index');?>
                                <?php endif?>" class="btn btn-primary">BOOK NOW</a>
                          </div>
                      </div>
                  </div>
                </div>
                <div class="col">
                  <div class="card">
                      <div class="card-horizontal">
                          <div class="img-square-wrapper">
                          <?php echo img("assets/images/presidential.png") ?>
                          </div>
                          <div class="card-body">
                            <h3 class="card-title" style="padding:10px;"><b>Connecting Rooms</b></h3>
                            <p class="card-text" style="font-size: 16px; padding-left: 13px;"><b>With your Stay:</b></p>
                            <p class="card-text" style="font-size: 14px; padding-left:15px;">Room Type: CON</p>
                            <p class="card-text" style="font-size: 14px; padding-left:15px;">Price: ₱ 7,000.00</p>
                            <a href="<?php 
                                if($this->session->userdata('loggedIn')):?>
                                <?php echo base_url('index.php/Rooms/form_con');?>
                                <?php else:?>
                                    <?php redirect('Homepage/index');?>
                                <?php endif?>" class="btn btn-primary">BOOK NOW</a>
                          </div>
                      </div>
                  </div>
                </div>
              </div>
              <br><br>
        </div>
        <br><br>
        <!--Start of the footer-->
    <footer class="footer">
        <!--Start of the footer container-->
        <div class="container">
            <!--Start of the footer-content-->
            <div class="footer-content">

                <div class="footer-content-brand">
                    <a href="<?php echo base_url('index.php/Homepage');?>" class="logo">
                    <img class="logo-image" src="<?php echo base_url(); ?>assets/images/hotellogo.png" alt="logo">
                    </a>
                    <div class="paragraph">
                        Lorem, ipsum dolor sit amet consectetur adipisicing 
                        elit. Porro reiciendis, quas sint eius omnis dicta 
                        molestias temporibus tenetur hic labore atque aliquid 
                        natus quasi ad, quae dolorem. Ipsum, magnam at.
                    </div>
                </div>

                <!--Start of social media icons-->
                <div class="social-media-wrap">
                    <h4 class="footer-heading">Follow Us</h4>
                    <div class="social-media">
                        <a href="#" class="sm-link"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="sm-link"><i class="fab fa-facebook-square"></i></a>
                        <a href="#" class="sm-link"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <!--End of social media icons-->

            </div>
            <!--End of the footer-content-->
        </div>
         <!--End of the footer container-->
    </footer>
    <!--End of the footer-->

    <script > let header = document.querySelector('.header');
let hamburgerMenu = document.querySelector('.hamburger-menu');

window.addEventListener('scroll', function(){
    let windowPosition = window.scrollY > 0;
    header.classList.toggle('active', windowPosition)
})

hamburgerMenu.addEventListener('click', function(){
    header.classList.toggle('menu-open');
})</script>
    </body>
</html>