<!Doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TailSlap | About</title>
    <!--Font awesome CDN-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <!--CSS Link-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/styles.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/about.css">
</head>

<body>
    <header class="header">
        <div class="container">
            <nav class="nav">
                <a href="<?php echo base_url('index.php/Homepage/home'); ?>" class="logo">
                <?php echo img('assets/images/hotelname.png'); ?>
                </a>
                <div class="hamburger-menu">
                    <i class="fas fa-bars"></i>
                    <i class="fas fa-times"></i>
                </div>
                <!--End of Hamburger menu-->

                <!--Start of Navigation Menu-->
                <ul class="nav-list">

                    <li class="nav-item">
                        <a href="<?php echo base_url('index.php/Homepage/home'); ?>" class="nav-link">Home</a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo base_url('index.php/Homepage/about'); ?>" class="nav-link">About</a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo base_url('index.php/Homepage/offer'); ?>" class="nav-link">Offers</a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo base_url('index.php/Homepage/contact'); ?>" class="nav-link">Contact</a>
                    </li>

                    <li class="nav-item">
                        <?php if ($this->session->userdata('loggedIn')) : ?>
                            <a href="<?php echo base_url('users_acc/acc');?>" class="nav-link">Account</a>
                        <?php else : ?>
                            <a href="<?php echo base_url('index.php/Homepage/login');?>" class="nav-link">Login</a>
                        <?php endif; ?>
                    </li>

                </ul>
            </nav>
        </div>
    </header>

    <div class="our-team" style="margin-top: 150px;">
        <div class="title-dev">
            DEVELOPERS
        </div>
    </div>

    <section>
        <div class="team">
            <?php echo img('assets/images/dev1.JPG'); ?>
            <div class="info">
                <div class="name">Adrian Panesa</div>
                <div class="title">Developer 1</div>
                <div class="social">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-instagram"></i>
                </div>
            </div>
        </div>
        <div class="team">
            <?php echo img('assets/images/dev2.JPG'); ?>
            <div class="info">
                <div class="name">Jan Martin Unay</div>
                <div class="title">Developer 2</div>
                <div class="social">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-instagram"></i>
                </div>
            </div>
        </div>

        <div class="team">
            <?php echo img('assets/images/dev3.JPG'); ?>
            <div class="info">
                <div class="name">Clifford Villanoy</div>
                <div class="title">Developer 3</div>
                <div class="social">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-instagram"></i>
                </div>
            </div>
        </div>

        <div class="team">
            <?php echo img('assets/images/dev4.JPG'); ?>
            <div class="info">
                <div class="name">David Andreu Villanueva</div>
                <div class="title">Developer 4</div>
                <div class="social">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-instagram"></i>
                </div>
            </div>
        </div>
    </section>
    <br><br><br><br>
    <footer class="footer">
        <!--Start of the footer container-->
        <div class="container">
            <!--Start of the footer-content-->
            <div class="footer-content">

                <div class="footer-content-brand">
                    <a href="index.php" class="logo">
                        <img class="logo-image" src="<?php echo base_url(); ?>assets/images/hotellogo.png" alt="logo">
                    </a>
                    <div class="paragraph">
                        Lorem, ipsum dolor sit amet consectetur adipisicing
                        elit. Porro reiciendis, quas sint eius omnis dicta
                        molestias temporibus tenetur hic labore atque aliquid
                        natus quasi ad, quae dolorem. Ipsum, magnam at.
                    </div>
                </div>

                <!--Start of social media icons-->
                <div class="social-media-wrap">
                    <h4 class="footer-heading">Follow Us</h4>
                    <div class="social-media">
                        <a href="#" class="sm-link"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="sm-link"><i class="fab fa-facebook-square"></i></a>
                        <a href="#" class="sm-link"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <!--End of social media icons-->

            </div>
            <!--End of the footer-content-->
        </div>
        <!--End of the footer container-->
    </footer>
    <script> //Selectors
let header = document.querySelector('.header');
let hamburgerMenu = document.querySelector('.hamburger-menu');

window.addEventListener('scroll', function(){
    let windowPosition = window.scrollY > 0;
    header.classList.toggle('active', windowPosition)
})

hamburgerMenu.addEventListener('click', function(){
    header.classList.toggle('menu-open');
}) </script>
</body>

</html>