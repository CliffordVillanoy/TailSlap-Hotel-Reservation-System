<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/admin.css">
    <title>TailSlap | Admin Panel</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/admin.css">
</head>

<body>
    <div class="side-menu">
        <div class="brand-name">
            <h1 style="color: rgb(201, 198, 198);">ADMIN</h1>
        </div>
        <ul>
            <li class="active"><a href="<?php echo base_url('index.php/Admin/dashboard'); ?>" data-toggle="tab" style="color: white"> <span>Dashboard</span></a></li>
            <li class="active"><a href="<?php echo base_url('index.php/libraries/logout/signout'); ?>" data-toggle="tab" style="color: white"> <span>Logout</span></a></li>
        </ul>
    </div>
    <div class="container"> 
        <div class="header">
            <div class="nav">
                <div class="user">
                    <h1>DASHBOARD</h1>
                </div>
            </div>
        </div>
        <div class="content">
            <br><br><br>
            <div class="content-2">
                <div class="recent-payments">
                    <div class="title">
                        <h2 style="color: white;">LIST OF BOOKINGS</h2>
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Transaction ID</th>
                                <th>Guest ID</th>
                                <th>Room Type</th>
                                <th>Penalty</th>
                                <th>Reservation</th>
                                <th>Check In</th>
                                <th>Check Out</th>
                                <th>Price</th>
                                <th>Status</th>
                                <th></th>
                                <th>Room Number</th>
                                <th>Card No</th>
                                <th>ModeOfPayment</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php

                            if($this->session->userdata('update') == true){echo '<script>alert("Data updated successfully")</script>';
                                $this->session->set_userdata(array('update'=>false));}
                            foreach ($DATA as $key) :
                            ?>

                                <tr>
                                    <td> <?php echo $key->TransactionID ?> </td>
                                    <td> <?php echo $key->GuestID ?> </td>
                                    <td> <?php echo $key->Roomtype ?> </td>
                                    <td> <?php echo $key->Penalty ?> </td>
                                    <td> <?php echo $key->Reservations ?> </td>
                                    <td> <?php echo $key->Checkin ?> </td>
                                    <td> <?php echo $key->Checkout ?> </td>
                                    <td> <?php echo $key->Price ?> </td>
                                    <td> <?php echo $key->Stats ?> </td>
                                    <td>


                                    <?php if ($key->Stats == 'PENDING') :?>
                                        <form action="<?php echo base_url('index.php/Admin/update_book_status'); ?>" method='POST'>
                                            <select type="submit" name="status" class="select">
                                                <?php if ($key->Stats == 'PENDING') : ?>
                                                    <option disabled selected>Pending</option>
                                                <?php elseif ($key->Stats == 'Accepted') : ?>
                                                    <option disabled selected>Pending</option>
                                                <?php elseif ($key->Stats == 'Declined') : ?>
                                                    <option disabled selected>Pending</option>

                                                <?php endif; ?>
                                                <option value="Accepted">Accepted</option>
                                                <option value="Declined">Declined</option>
                                            </select>
                                            <?php
                                            ?>


                                    </td>
                                    <td>

                                        <select type="submit" name="roomnumber" class="select">
                                            <option value="<?php echo $key->Roomnumber ?>"><?php echo $key->Roomnumber ?></option>
                                        </select>
                                        <?php
                                        ?>
                                        <button type="submit" class="conf" name="btnconfirm">Confirm</button>
                                        </form>
                                        <?php endif; ?> 
                                    </td>
                                    <td> <?php echo $key->Cardnumber ?> </td>
                                    <td> <?php echo $key->ModeOfPayment ?> </td>

                                </tr>

                            <?php
                            endforeach;
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>

</html>