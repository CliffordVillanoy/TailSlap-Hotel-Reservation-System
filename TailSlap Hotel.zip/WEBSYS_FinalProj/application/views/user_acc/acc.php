    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <title>TailSlap | Account </title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" type="image" href="assets/images/hotellogo.png" alt="logo">
        <link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
        <!-- add style css  -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/styles.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/acc.css">

    </head>

    <body>
        <header class="header">
            <div class="container">
                <nav class="nav">
                    <a href="<?php echo base_url('index.php/Homepage'); ?>" class="logo">
                        <?php echo img("assets/images/hotelname.png") ?>
                    </a>
                    <div class="hamburger-menu">
                        <i class="fas fa-bars"></i>
                        <i class="fas fa-times"></i>
                    </div>
                    <!--End of Hamburger menu-->

                    <!--Start of Navigation Menu-->
                    <ul class="nav-list">

                        <li class="nav-item">
                            <a href="<?php echo base_url('index.php/Homepage/home'); ?>" class="nav-link">Home</a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo base_url('index.php/Homepage/about'); ?>" class="nav-link">About</a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo base_url('index.php/Homepage/offer'); ?>" class="nav-link">Offers</a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo base_url('index.php/Homepage/contact'); ?>" class="nav-link">Contact</a>
                        </li>

                        <li class="nav-item">
                            <?php if ($this->session->userdata('loggedIn')) : ?>
                                <a href="<?php echo base_url('index.php/Account/show_account'); ?>" class="nav-link">Account</a>
                            <?php else : ?>
                                <a href="login.php" class="nav-link">Login</a>
                            <?php endif; ?>
                        </li>
                    </ul>
                </nav>
            </div>
        </header>
        <div class="container bootstrap snippets bootdey" style="margin-top: 250px;">
            <div class="row">
                <!-- BEGIN USER PROFILE -->
                <div class="col-xl-12" style="width: 1500px; margin-left: -150px;">
                    <div class="grid profile">
                        <div class="grid-header">
                            <div class="col-sm-2">
                            <img src="<?php echo base_url('uploads/'.$this->session->userdata('Profile')['DP']); ?>" class="img-circle">
                                
                            </div>
                            <div class="col-xs-7 inf">
                                <h3><?php echo $this->session->userdata('loggedIn')['fullname']; ?></h3>
                                <p><?php echo $this->session->userdata('loggedIn')['user_email']; ?></p>
                                <form action="<?php echo base_url('index.php/Account/add_image') ?>" method="POST" enctype="multipart/form-data">

                                    <input type="file" class="btn btn-gradient" name="img">

                                    <input type="submit" name="submit" value="Upload" class="btn btn-gradient">
                                </form>



                            </div>
                        </div>
                        <div class="grid-body">
                            <ul class="nav nav-tabs">
                                <li class="active"><a href="#profile" data-toggle="tab">Profile</a></li>
                                <li class=""><a href="#timeline" data-toggle="tab">Booking</a></li>
                                <?php

                                if (count($user_data) > 0) {
                                    foreach ($user_data as $key) :
                                        $key->Stats;
                                    endforeach;
                                    $status = $this->session->userdata('BookedIn')['Status'];
                                }

                                if (count($user_data) > 0 and $key->Stats == "PENDING") :    ?>

                                    <li class=""><a href="#change" data-toggle="tab">Change Room</a></li>
                                <?php endif; ?>

                                <?php
        

                                if (count($user_data) > 0 and $status != "PENDING") :    ?>

                                    <li class=""><a href="#checkout" data-toggle="tab">Check Out</a></li>
                                <?php endif; ?>

                                <?php




                                if (count($user_data) > 0 and $key->Stats == "PENDING") :    ?>
                                    <li class=""><a href="#cancel" data-toggle="tab">Cancel Booking</a></li>
                                <?php endif; ?>
                                <li class=""><a href="<?php echo base_url('index.php/libraries/logout/signout'); ?>">Logout</a></li>
                            </ul>
                            <div class="tab-content">
                                <!-- BEGIN PROFILE -->
                                <div class="tab-pane active" id="profile">
                                    <br>
                                    <p class="lead">My Profile</p>

                                    <hr>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p><strong>Guest ID:</strong> <a><?= $this->session->userdata('loggedIn')['GuestId']; ?></a></p>
                                            <p><strong>Name:</strong> <a><?= $this->session->userdata('loggedIn')['fullname']; ?></a></p>
                                            <p><strong>Email Address:</strong> <a><?= $this->session->userdata('loggedIn')['user_email']; ?></a></p>
                                        </div>
                                    </div>
                                </div>
                                <!-- END PROFILE -->

                                <!-- BEGIN TIMELINE -->
                                <div class="tab-pane" id="timeline">
                                    <br>
                                    <p class="lead">My Booking</p>
                                    <hr>
                                    <div class="border border-dark round-3 border-3 p-3 bg-white w-75">
                                        <hr>
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>Transaction ID</th>
                                                    <th>Guest ID</th>
                                                    <th>Room Type</th>
                                                    <th>Price</th>
                                                    <th>Check In</th>
                                                    <th>Check Out</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php


                                                if (count($user_data) > 0) :
                                                    foreach ($user_data as $key) :
                                                ?>

                                                        <tr>
                                                            <td> <?php echo $key->TransactionID ?> </td>
                                                            <td> <?php echo $key->GuestID ?> </td>
                                                            <td> <?php echo $key->Roomtype ?> </td>
                                                            <td> <?php echo $key->Price ?> </td>
                                                            <td> <?php echo $key->Checkin ?> </td>
                                                            <td> <?php echo $key->Checkout ?> </td>
                                                            <td> <?php echo $key->Stats ?> </td>
                                                        </tr>

                                                <?php
                                                    endforeach;
                                                endif;
                                                ?>
                                            </tbody>
                                        </table>
                                        <br><Br>
                                    </div>
                                </div>
                                <!-- END TIMELINE -->

                                <!-- BEGIN SETTINGS -->
                                <div class="tab-pane" id="change">
                                    <br>
                                    <p class="lead">View Rooms</p>
                                    <hr>
                                    <div class="container">
                                        <div class="search_wrap search_wrap_5">
                                            <div class="search_box">
                                                <form action="<?php echo base_url('index.php/Account/room_check'); ?>" method="POST">
                                                    <input type="text" name="checkroom" class="input" placeholder="Type to search" style="height: 52px;">
                                                    <div class="btn">
                                                        <button type="submit" name="btncheckroom" style="font-size: 12px; height: 50px; width: 500px;">Search</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <br><br>
                                <div class="border border-dark round-3 border-3 p-3 bg-white w-75">
                                    <hr>
                                    <h3?>Room Availability</h3>
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>Transaction ID</th>
                                                    <th>Guest ID</th>
                                                    <th>Room Type</th>
                                                    <th>Room Number</th>
                                                    <th>Check In</th>
                                                    <th>Check Out</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <?php if ($this->session->userdata('loggedIn') and $click == true) : ?>
                                                        <?php foreach ($Rooms as $key) : ?>
                                                            <td> <?php echo $key->TransactionID ?> </td>
                                                            <td> <?php echo $key->GuestID ?> </td>
                                                            <td> <?php echo $key->Roomtype ?> </td>
                                                            <td> <?php echo $key->Roomnumber ?> </td>
                                                            <td> <?php echo $key->Checkin ?> </td>
                                                            <td> <?php echo $key->Checkout ?> </td>
                                                            <td> <?php echo $key->Stats ?> </td>

                                                        <?php endforeach; ?>
                                                        <td> <?php if (($ROWS) == 0) {
                                                                    echo "No Transaction ID";
                                                                } ?> </td>
                                                        <td> <?php if (($ROWS) == 0) {
                                                                    echo "";
                                                                } ?> </td>
                                                        <td> <?php if (($ROWS) == 0) {
                                                                    echo "$roomtype";
                                                                } ?> </td>
                                                        <td> <?php if (($ROWS) == 0) {
                                                                    echo "$roomnum";
                                                                } ?> </td>
                                                        <td> <?php if (($ROWS) == 0) {
                                                                    echo "None";
                                                                } ?> </td>
                                                        <td> <?php if (($ROWS) == 0) {
                                                                    echo "None";
                                                                } ?> </td>
                                                        <td> <?php if (($ROWS) == 0 and $Status == 'EXIST') {
                                                                    echo "Available";
                                                                } elseif ($Status != 'EXIST') {
                                                                    echo "DOESN'T EXIST";
                                                                }    ?> </td>
                                                    <?php endif; ?>
                                                </tr>

                                            </tbody>
                                        </table>
                                        <br><Br>
                                        <center>
                                            <form action="<?php echo base_url('index.php/Account/change_room'); ?>" method="POST">
                                                <button type="submit" name="btnchangeroom" class="submit">Confirm</button>
                                            </form>
                                        </center>
                                </div>
                            </div>
                            <!-- END SETTINGS -->

                            <!-- check out -->
                            <div class="tab-pane" id="checkout">
                                <br>
                                <p class="lead">Check Out</p>
                                <hr>
                                <div class="form sign-up">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Room Number</th>
                                                <th>Room Type</th>
                                                <th>Price</th>
                                                <th>Check In</th>
                                                <th>Check Out</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <?php


                                                if (count($user_data) > 0) :
                                                    foreach ($user_data as $key) :

                                                ?>

                                            <tr>
                                                <td> <?php echo $key->Roomnumber ?> </td>
                                                <td> <?php echo $key->Roomtype ?> </td>
                                                <td> <?php echo $key->Price ?> </td>
                                                <td> <?php echo $key->Checkin ?> </td>
                                                <td><a href="<?php echo base_url('index.php/libraries/Checkout/checkout'); ?>/<?php echo $key->Roomnumber ?>">Confirm</a></td>
                                            </tr>

                                    <?php
                                                    endforeach;
                                                endif;
                                    ?>
                                    </tr>
                                        </tbody>
                                    </table>
                                    <Br>
                                </div>
                            </div>
                            <!-- check out -->
                            <!-- Cancel booking -->
                            <?php


                            if (count($user_data) > 0) : ?>
                                <div class="tab-pane" id="cancel">

                                    <div class="tab-pane" id="cancel">
                                        <br>
                                        <p class="lead">Current Booking</p>
                                        <hr>
                                        <div class="form sign-up">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>Room Number</th>
                                                        <th>Room Type</th>
                                                        <th>Price</th>
                                                        <th>Check In</th>
                                                        <th>Check Out</th>
                                                        <th>Cancel</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <?php


                                                        if (count($user_data) > 0) :
                                                            foreach ($user_data as $key) :
                                                        ?>

                                                    <tr>
                                                        <td> <?php echo $key->Roomnumber ?> </td>
                                                        <td> <?php echo $key->Roomtype ?> </td>
                                                        <td> <?php echo $key->Price ?> </td>
                                                        <td> <?php echo $key->Checkin ?> </td>
                                                        <td> <?php echo $key->Checkout ?> </td>
                                                        <td><a href="<?php echo base_url('index.php/libraries/booking/penalty'); ?>/<?php echo $key->Roomnumber ?>">Confirm</a></td>
                                                    </tr>

                                            <?php
                                                            endforeach;
                                                        endif;
                                            ?>
                                            </tr>
                                                </tbody>
                                            </table>
                                        <?php endif; ?>
                                        <Br>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
                <!-- END USER PROFILE -->
            </div>
        </div>
        <script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
        <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <script type="text/javascript">

        </script>
    </body>

    </html>