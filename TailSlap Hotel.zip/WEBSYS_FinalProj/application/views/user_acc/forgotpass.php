<!DOCTYPE html>
<html>

<head>
  <title>TailSlap | Forgot Password</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/styles.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/login.css">

  <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700,800&display=swap" rel="stylesheet">
</head>

<body>
  <!--Start of Hamburger menu-->
  <header class="header">
    <div class="container">
      <nav class="nav">
        <a href="<?php echo base_url('index.php/Homepage/home'); ?>" class="logo">
          <?php echo img('assets/images/hotelname.png'); ?>
        </a>
        <div class="hamburger-menu">
          <i class="fas fa-bars"></i>
          <i class="fas fa-times"></i>
        </div>
        <!--End of Hamburger menu-->

        
      </nav>
    </div>
  </header>
  <!--End of Navigation Menu-->

  <div class="cont">

    <form action="<?php echo base_url('index.php/libraries/forgotpass/changepass'); ?>" method="POST">
      <div class="form sign-in">
        <h2>Change Password</h2>    
        <label>
          <span>Email</span>
          <input id="email" type="text" name="email" value="<?php echo set_value('email'); ?>">
          <p><?php echo form_error('email'); ?></p>
          <p>
          <?php if($this->session->userdata('usr_email') == False); 
          { echo $this->session->flashdata('usr_acc');}?>
          </p>

        </label>

        <label>
          <span>New Password</span>
          <input id="password" type="text" name="password" value="<?php echo set_value('password'); ?>">
          <p><?php echo form_error('password'); ?></p>

        </label>

        <label>
          <span>Confirm New Password</span>
          <input type="password" name="confpass" value="<?php echo set_value('confpass'); ?>">
          <p><?php echo form_error('confpass'); ?></p>

        </label>
        <button class="submit" type="submit" onclick="errorMessage()" name="btnLogin">Change Password</button>
    </form>
    

  </div>



  <div class="sub-cont">
    <div class="img">
      <div class="img-text m-up">
        <h2>Forgot Password?</h2>
        <p>Always remember to save your password or write it in a piece of paper.</p>
      </div>

    </div>

  </div>
  </div>

  <script>
    document.querySelector('.img-btn').addEventListener('click', function() {
      document.querySelector('.cont').classList.toggle('s-signup')
    });
  </script>
</body>

</html>