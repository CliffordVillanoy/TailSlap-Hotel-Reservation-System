<?php date_default_timezone_set('Asia/Manila'); ?>

<!Doctype html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>TailSlap | Hotel Form</title>
        <link rel = "icon" href = "hotellogo.png" type = "image/x-icon">
        <link rel="stylesheet" href="assets/form.css">
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="wrapper">
            <h2>Hotel Form</h2>
            <form action="<?php echo base_url('index.php/libraries/booking/book_process');?>" method="POST">
                <!--Account Information Start-->
                <h4>Full Name</h4>
                <!--Name-->
                <div class="input_group">
                    <div class="input_box">
                        <input type="text" placeholder="First Name" name="firstname" class="name" value="<?php echo $this->session->userdata('loggedIn')['firstname']?>" readonly>
                        
                    </div>
                    <div class="input_box">
                        <input type="text" placeholder="Last Name" name="lastname" class="name" value="<?php echo $this->session->userdata('loggedIn')['lastname'] ?>" readonly>
                        
                    </div>
                </div>
                <!--Email Address-->
                <div class="input_group">
                    <div class="input_box">
                        <input type="email" placeholder="Email Address" name="email" class="name"  value="<?php echo $this->session->userdata('loggedIn')['user_email'] ?>" readonly>
                        
                    </div>
                </div>
    
                <!--Room Type-->
                <div class="input_group">
                    <div class="input_box">
                    
                    <input type="text" name="roomtype" class="name" value="CON" readonly>
                    
                    </div>
                </div>         

                <!-- Reservation -->
                <div class="input_group">
                    <!--Number of adults-->
                    <div class="input_box">
                        <input type="text" placeholder="Number of adults" name="numAdults" required class="name">
                    </div>
                    <!--Number of children-->
                        <div class="input_box">
                            <input type="text" placeholder="Number of children" name="numKids" required class="name">
                        </div>
                
                </div>
                <!--Account Information End-->
    
    
                <!--Payment Details Start-->
                <div class="input_group">
                    <div class="input_box">
                        <h4>Payment Details</h4>
                        <input type="radio" name="pay" class="radio" id="bc1" value="CREDIT" checked>
                        <label for="bc1"><span>Credit Card</span></label>
                        <input type="radio" name="pay" class="radio" value="DEBIT" id="bc2">
                        <label for="bc2"><span>Debit Card</span></label>
                    </div>
                </div>
    
                <!--Payment Information-->
                
                <div class="input_group">
                    <div class="input_box">
                        <input type="text" placeholder="Credit or Debit Card Number" name="Credit-Debit" required class="name">
                        
                    </div>
                </div>
    
                <!--Name-->
                <div class="input_group">
                    <div class="input_box">
                        <input type="text" name="fullname" class="name" placeholder="Full Name" value="<?php echo $this->session->userdata('loggedIn')['fullname']; ?>" readonly>
                        <i class="fa fa-user icon"></i>
                    </div>
                </div>   
    
                <!--Check-in and Check-out-->
                <div class="input_group">
                    <div class="input_box">
                        <input type="date" name="checkinDate" class="name" min="<?php echo date('Y-m-d', strtotime('+2 days')); ?>" required> 
                    </div>
                    <div class="input_box">
                        <div class="input_box">
                            <input type="date"  name="checkoutDate" class="name" min="<?php echo date('Y-m-d', strtotime('+2 days')); ?>" required>
                        </div>
                    </div>
                </div>
                <!--Payment Details End-->
    
                <div class="input_group">
                    <div class="input_box">
                        <button type="submit" name="submit">PAY NOW</button>
                    </div>
                </div>
    
            </form>
        </div>
    </body>
</html>