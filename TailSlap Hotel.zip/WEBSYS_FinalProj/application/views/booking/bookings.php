<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/admin.css">
    <title>TailSlap | Admin Panel</title>
</head>

<body>
    <div class="side-menu">
        <div class="brand-name">
            <h1 style="color: rgb(201, 198, 198);">ADMIN</h1>
        </div>
        <ul>
            <li class="active" ><a href="admin.php" data-toggle="tab" style="color: white"> &nbsp;<span>Dashboard</span></a></li>
            <li class="active"><a href="bookings.php" data-toggle="tab" style="color: white"> &nbsp;<span>Bookings</span></a></li>
            <li class="active"><a href="messages.php" data-toggle="tab" style="color: white"> &nbsp;<span>Messages</span></a></li>
            <li class="active"><a href="index.php" data-toggle="tab" style="color: white"> &nbsp;<span>Logout</span></a></li>
        </ul>
    </div>
    <div class="container">
        <div class="header">
            <div class="nav">
                <div class="user">
                    <h1>BOOKINGS</h1>
                </div>
            </div>
        </div>
        <div class="content">
            <br><br><br>
            
            
            <div class="content-2" id="bookings">
                <div class="recent-payments">
                    <div class="title">
                        <h2 style="color: white;">LIST OF BOOKINGS</h2>
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Transaction ID</th>
                                <th>Guest ID</th>
                                <th>Room Type</th>
                                <th>Room No</th>
                                <th>Reservation</th>
                                <th>Check In</th>
                                <th>Check Out</th>
                                <th>Price</th>
                                <th>Status</th>
                                <th>Payment</th>
                                <th>Card No</th>
                                <th>Penalty</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                                require_once("resources/config.php");

                                $query = "SELECT * FROM tblbooking";
                                $result = $conn -> query($query);
                                $rowCount = $result -> num_rows;

                                if ($rowCount > 0):
                                    while ($row = $result -> fetch_assoc()):
                            ?>

                                <tr>
                                    <td> <?php echo $row["TransactionID"] ?> </td>
                                    <td> <?php echo $row["GuestID"] ?> </td>
                                    <td> <?php echo $row["Roomtype"] ?> </td>
                                    <td> <?php echo $row["Roomnumber"] ?> </td>
                                    <td> <?php echo $row["Reservations"] ?> </td>
                                    <td> <?php echo $row["Checkin"] ?> </td>
                                    <td> <?php echo $row["Checkout"] ?> </td>
                                    <td> <?php echo $row["Price"] ?> </td>
                                    <td> <?php echo $row["Status"] ?> </td>
                                    <td> <?php echo $row["ModeOfPayment"] ?> </td>
                                    <td> <?php echo $row["Cardnumber"] ?> </td>
                                    <td> <?php echo $row["Penalty"] ?> </td>


                                </tr>

                            <?php
                                    endwhile;
                                endif;
                            ?>
                          </tbody>
                    </table>
                </div>
            </div>

            
        </div>
    </div>
</body>

</html>