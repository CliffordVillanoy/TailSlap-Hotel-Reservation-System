<?php

class Account extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('acc_mod');
        $this->load->model('roomCheck_mod');
        $this->load->library("session");
    }

    public function secure()
    {
        if ($this->session->userdata('loggedIn')) {
            return true;
        } else {
            redirect('/Homepage/home');
        }
    }

    public function index()
    {
        $this->show_account();
    }

    public function show_account()
    {
        if ($this->secure() == true) {
            echo link_tag('assets/css/acc.css');
            echo link_tag('assets/css/styles.css');
            $roomtype = "";
            $status = "";

            $user_id = $this->session->userdata('loggedIn')['GuestId'];
            $roomnumber = $this->input->post('checkroom');

            if ($roomnumber > 100 and $roomnumber <= 130) :
                $roomtype = "KIN";
                $status = 'EXIST';

            elseif ($roomnumber > 200 and $roomnumber <= 230) :
                $roomtype = "EXE";
                $status = 'EXIST';

            elseif ($roomnumber > 300 and $roomnumber <= 330) :
                $roomtype = "PRE";
                $status = 'EXIST';

            elseif ($roomnumber > 400 and $roomnumber <= 430) :
                $roomtype = "CAB";
                $status = 'EXIST';

            elseif ($roomnumber > 500 and $roomnumber <= 530) :
                $roomtype = "VIL";
                $status = 'EXIST';

            elseif ($roomnumber > 600 and $roomnumber <= 630) :
                $roomtype = "CON";
                $status = 'EXIST';
            endif;

            $data1 = $this->acc_mod->acc_bookings($user_id);
            $data2 = $this->acc_mod->show_row($user_id);
            $data3 = $this->roomCheck_mod->check_room($roomnumber);
            $data4 = $this->roomCheck_mod->check_rows($roomnumber);
            $click = $this->session->userdata('click')['click'];


            $capsule = array(
                'user_data' => $data1, 'row' => $data2, 'Rooms' => $data3, 'ROWS' => $data4, 'roomnum' => $roomnumber, 'roomtype' => $roomtype,
                'Status' => $status,'click'=>$click
            );
            $this->load->view('user_acc/acc', $capsule);

            $sess = array('Newroom' => $roomtype, 'NewroomNumber' => $roomnumber);
            $this->session->set_userdata('Changeroom', $sess);
        }
    }

    public function room_check()
    {

        echo link_tag('assets/css/acc.css');
        echo link_tag('assets/css/styles.css');
        $roomnumber = $this->input->post('checkroom');
        $roomtype = "";
        $status = "";


        if ($roomnumber > 300 and $roomnumber <= 330) :
            $roomtype = "PRE";
            $status = 'EXIST';

        elseif ($roomnumber > 400 and $roomnumber <= 430) :
            $roomtype = "CAB";
            $status = 'EXIST';

        elseif ($roomnumber > 500 and $roomnumber <= 530) :
            $roomtype = "VIL";
            $status = 'EXIST';

        elseif ($roomnumber > 600 and $roomnumber <= 630) :
            $roomtype = "CON";
            $status = 'EXIST';
        endif;

        //echo $roomnumber;
        //echo $roomtype;
        //echo $this->session->userdata('ROOMtn')['Roomtyp'];
        //echo $this->session->userdata('ROOMtn')['Roomnum'];

        $user_id = $this->session->userdata('loggedIn')['GuestId'];

        $data1 = $this->acc_mod->acc_bookings($user_id);

        $data2 = $this->acc_mod->show_row($user_id);

        $data3 = $this->roomCheck_mod->check_room($roomnumber);
        $data4 = $this->roomCheck_mod->check_rows($roomnumber);
        $click = $this->session->userdata('click',true);


        $capsule = array(
            'user_data' => $data1, 'row' => $data2, 'Rooms' => $data3, 'ROWS' => $data4, 'roomnum' => $roomnumber, 'roomtype' => $roomtype,
            'Status' => $status,'click'=>$click
        );

        $this->load->view('user_acc/acc', $capsule);

        $rtype = array('Roomtyp' => $roomtype, 'Roomnum' => $roomnumber);
        $this->session->set_userdata('ROOMtn', $rtype); // will use for new room type and new room number
    }

    public function change_room()
    {
        $user_id = $this->session->userdata('loggedIn')['GuestId'];
        $guests = $this->acc_mod->acc_bookings($user_id);
        $user = $this->acc_mod->fetch_users($user_id);

        foreach ($guests as $key) {
            $key->Reservations;
            $key->Checkin;
            $key->Checkout;
            $key->Roomtype;
        }
        $numOFguest = $key->Reservations;
        $checkin = $key->Checkin;
        $checkout = $key->Checkout;
        $oldtype = $key->Roomtype;
        //echo "this is old type".$oldtype;


        foreach ($user as $key) {
            $key->Firstname;
            $key->Lastname;
        }
        $firstname = $key->Firstname;
        $lastname = $key->Lastname;


        $Newroomtype = $this->session->userdata('ROOMtn')['Roomtyp'];
        //echo "this is new type".$Newroomtype;

        $transactionID = (strtoupper(substr($firstname, 0, 1)) .
            strtoupper(substr($lastname, 0, 1)) .
            strtoupper(date_format(date_create($checkin), "Md")) .
            date_format(date_create($checkin), "m") .
            substr(date_format(date_create($checkin), "Y"), -2) .
            "-" .
            strtoupper(substr($Newroomtype, 0, 3)) .
            sprintf("%05d", $numOFguest)
        );

        $dayDifference = floor((strtotime($checkout) - strtotime($checkin)) / (60 * 60 * 24));
        $price = 0;
        if ($Newroomtype == "KIN")
            $price = 2000 * $dayDifference;
        elseif ($Newroomtype == "EXE")
            $price = 3000 * $dayDifference;
        elseif ($Newroomtype == "PRE")
            $price = 4000 * $dayDifference;
        elseif ($Newroomtype == "CAB")
            $price = 5000 * $dayDifference;
        elseif ($Newroomtype == "VIL")
            $price = 6000 * $dayDifference;
        elseif ($Newroomtype == "CON")
            $price = 7000 * $dayDifference;
        //echo "Price: " . $price;


        $Newroomnumber = $this->session->userdata('ROOMtn')['Roomnum']; // eto yung chineck nya na number
        //echo "this is new number".$Newroomnumber;
        $geustid = $this->session->userdata('loggedIn')['GuestId'];
        $data = $this->acc_mod->acc_bookings($geustid);
        foreach ($data  as $key) {
            $key->Roomnumber;
        }
        $currentroomnum = $key->Roomnumber;

        //$currentroomnum = $this->session->userdata('BookedIn')['Room_Number'];// eto yung current na naka book na room number
        //echo "this is old number".$currentroomnum;
        $NewStatus = "PENDING";
        $oldtransactionid = $this->session->userdata('BookedIn')['Transaction_ID'];

        $capsule = array('TransactionID' => $transactionID, 'Roomtype' => $Newroomtype, 'Price' => $price, 'Roomnumber' => $Newroomnumber, 'Stats' => $NewStatus);
        $update = $this->acc_mod->update_room($currentroomnum, $user_id, $capsule, $oldtransactionid);
        if ($update) {
            redirect('/Account/show_account');
            echo "success!";
            echo $currentroomnum;
        } else echo "error!";
    }

    public function add_image()
    {
        if ($this->secure() == true) {
            $config['upload_path']          = './uploads   ';
            $config['allowed_types']        = 'jpg|jpeg|png|gif';
            $config['max_size']             = 2048;
            //$config['max_width']            = 1024;
            //$config['max_height']           = 768;

            $this->load->library('upload', $config);
            $this->upload->initialize($config);


            if (!$this->upload->do_upload('img')) {
                print_r($this->upload->display_errors());
            } else {
                $user_id = $this->session->userdata('loggedIn')['GuestId'];
                $filedata = $this->upload->data();
                $filename = $filedata['file_name'];
                $capsule = array('image' => $filename);
                $data1 = $this->acc_mod->save($capsule, $user_id);
            }

            $data2 = $this->acc_mod->fetch_bookings($user_id);  
            $data3 = array('DP' => $data2[0]->image);
            $this->session->set_userdata('Profile', $data3);
            


            $this->load->view('user_acc/acc');
        }
    }

    public function uploadform()
    {
        $this->load->view('user_acc/uploadfile');
    }

    public function forgotpass()
    {
        
    }

}
