<?php

class Rooms extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        //$this->load->model('Login_mod');
        $this->load->library('form_validation');
        $this->load->library("session");

    }

    public function form_pre()
    {
        echo link_tag('assets/css/form.css');
        $this->load->view('booking/payment_form/form_pre');
    }
    public function form_cab()
    {
        echo link_tag('assets/css/form.css');
        $this->load->view('booking/payment_form/form_cab');
    }
    public function form_con()
    {
        echo link_tag('assets/css/form.css');
        $this->load->view('booking/payment_form/form_con');
    }
    public function form_vil()
    {
        echo link_tag('assets/css/form.css');
        $this->load->view('booking/payment_form/form_vil');
    }
}
?>