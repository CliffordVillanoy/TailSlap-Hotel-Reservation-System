<?php

class Admin extends CI_Controller{


    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('acc_mod');
        $this->load->model('admin_mod');
        $this->load->library("session");
    }

    public function index()
    {
        $this->dashboard();
    }

    public function dashboard(){
        //echo link_tag('assets/css/admin.css');
        $data = $this->admin_mod->get_data();
        $capsule = array('DATA' => $data);
        $this->load->view('admin/admin',$capsule);
    }

    public function update_book_status()
    {
        $data = $this->admin_mod->get_data();
        
        foreach ($data as $key)
        {
            $key->GuestID;
            $key->Roomnumber;
            $key->Stats;
            $key->TransactionID;
        }
        $GuestID = $key->GuestID;
        $Roomnumber = $this->input->post('roomnumber');
        //$TransactionID = $key->TransactionID;
        $status = $this->input->post('status');
        $capsule = array('Stats' => $status);
        $data = $this->admin_mod->update_bookings($status,$Roomnumber,$capsule);
        $data = $this->admin_mod->get_data();
        $capsule = array('DATA' => $data);
        $this->load->view('admin/admin',$capsule);

    }

}?>