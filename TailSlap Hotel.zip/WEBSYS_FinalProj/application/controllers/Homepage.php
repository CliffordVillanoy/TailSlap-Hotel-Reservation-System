<?php

class Homepage extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        //$this->load->model('Login_mod');
        $this->load->library('form_validation');
        $this->load->library("session");

    }

    public function index () 
    {
        
        $this->home();
    }

    public function secure()
    {
        if($this->session->userdata('loggedIn'))
        {
            return true;
        }else{
            redirect('/homepage');}
    }

    public function home () 
    {
         echo link_tag('assets/css/styles.css');
        // echo link_tag('assets/js/main.js');
        // echo link_tag('assets/js/main.js');
        $this->load->view('mainpage/index');
    }

    public function about() 
    {
        echo link_tag('assets/css/styles.css');
        echo link_tag('assets/css/about.css');
        echo link_tag('assets/js/main.js');
        $this->load->view('mainpage/about');
    }

    public function offer() 
    {
        echo link_tag('assets/css/styles.css');
        $this->load->view('mainpage/offer');
    }

    public function contact() 
    {
        echo link_tag('assets/css/styles.css');
        $this->load->view('mainpage/contact');
    }

    public function login() 
    {
        echo link_tag('assets/css/login.css');
        echo link_tag('assets/css/styles.css');
        echo link_tag('https://fonts.googleapis.com/css?family=Nunito:400,600,700,800&display=swap');
        echo link_tag('assets/js/script.js');
        $this->load->view('mainpage/login');
    }

    public function account() 
    {
        if($this->secure() == true)
        {
        // echo link_tag('assets/css/acc.css');
        // echo link_tag('assets/css/styles.css');
        $this->load->view('user_acc/acc');
        }
    }

    public function explore_room() 
    {
        echo link_tag('assets/css/styles.css');
        echo link_tag('assets/js/main.js');
        $this->load->view('mainpage/explore_room');
    }

    public function prac() 
    {
        echo link_tag('assets/css/styles.css');
        echo link_tag('assets/js/main.js');
        $this->load->view('mainpage/prac');
    }


    

}


?>