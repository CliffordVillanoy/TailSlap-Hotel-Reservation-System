<?php

class Signup extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->helper('html');
        $this->load->helper('url');
        $this->load->library('form_validation');
        $this->load->model('signup_mod');
        $this->load->library('session');

    }
    public function signup_form () 
    {
       
        $this->form_validation->set_rules('firstname', 'Firstname', 'callback_username_check','callback_field_check');
        $this->form_validation->set_rules('lastname', 'Lastname', 'callback_username_check','callback_field_check');
        $this->form_validation->set_rules('password','Password','required', array('required' => 'You must provide a %s.','callback_field_check')
        );


        $this->form_validation->set_rules('confirmpassword', 'confirm password', 'required|matches[password]','callback_field_check');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email','callback_field_check');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            $this->load->view('mainpage/login');

        } else {

            $user_email = $this->input->post('email');
            $user_pass = $this->input->post('password');
            $firstname = $this->input->post('firstname');
            $lastname = $this->input->post('lastname');
            
            
            $capsule = array('Firstname'=> $firstname,'Lastname'=> $lastname,'Email'=> $user_email,'Password'=> $user_pass);
            $data = $this->signup_mod->insert_data($capsule);
            redirect('/Homepage/login');
            
        }



        


    }

    public function username_check($str) {
        if ($str == NULL) {
            $this->form_validation->set_message('username_check', 'The field cannot be blank');
            return FALSE;
        }
        else return TRUE;
    }

    public function field_check($str) {
        if ($str == "") {
            $this->form_validation->set_message('field_check', 'Required');
            return FALSE;
        }
        else return TRUE;
    }


}


    


?>
