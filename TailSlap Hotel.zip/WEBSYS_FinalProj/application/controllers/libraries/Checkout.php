<?php

class Checkout extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('checkout_mod');
        $this->load->library('form_validation');
        $this->load->library("session");

    }


    public function checkout($roomnumber)
    {
        
        $delete_data = $this->checkout_mod->checkout($roomnumber);
        redirect('Account/show_account');
    }

}?>
