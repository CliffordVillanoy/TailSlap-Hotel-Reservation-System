<?php

class Signin extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->database();
        $this->load->model('signin_mod');
        $this->load->library('form_validation');
        $this->load->library("session");
        $this->load->helper('html');
    }
    public function signin_form()
    {
        $this->form_validation->set_rules('signin_email', 'Email', 'trim|required');
        $this->form_validation->set_rules('signin_password', 'Password', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            $this->load->view('mainpage/login');
        } else {

            $user_email = $this->input->post('signin_email');
            $user_pass = $this->input->post('signin_password');
            if ($user_email != 'admin' and $user_pass != 'admin') {
                $session = $this->signin_mod->user_check($user_email, $user_pass);
            } //check sa db kung tama yung credentials na nilagay sa siginup form

            if ($user_email == 'admin' and $user_pass == 'admin') {
                redirect('Admin/dashboard');
            }

            if (count($session) > 0) {
                $sess_array = array(
                    'GuestId' => $session[0]->GuestID,
                    'user_email' => $session[0]->Email,
                    'fullname' => $session[0]->Fullname,
                    'firstname' => $session[0]->Firstname,
                    'lastname' => $session[0]->Lastname,
                    'DP' => $session[0]->image,
                    'click' => false,

                );
                $this->session->set_userdata('loggedIn', $sess_array);
                $this->session->set_userdata('Profile', $sess_array);
                $this->session->set_userdata('click', $sess_array);




                $ID = $this->session->userdata('loggedIn')['GuestId'];
                $session = $this->signin_mod->bookings_check($ID);
                if (count($session) > 0) {
                    $sess_array = array(
                        'Transaction_ID' => $session[0]->TransactionID,
                        'Room_Status' => $session[0]->Stats,
                        'Room_type' => $session[0]->Roomtype,
                        'Room_Number' => $session[0]->Roomnumber,
                        'Check_In' => $session[0]->Checkin,
                        'Cardnumber' => $session[0]->Cardnumber,
                        'Price' => $session[0]->Price,
                        'Penalty' => $session[0]->Penalty,
                        'Status' => $session[0]->Stats,
                        'Check_Out' => $session[0]->Checkout,
                    );
                    $this->session->set_userdata('BookedIn', $sess_array);
                }


                redirect('Account/show_account');
            } else {    
                $_SESSION['acc'] = "Account isn't connected to an account or wrong password";
                $this->session->mark_as_flash('acc');
            

                $this->load->view('mainpage/login');
            }
        }
    }
}
