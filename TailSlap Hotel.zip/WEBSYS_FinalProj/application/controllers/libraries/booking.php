<?php

class Booking extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('booking_mod');
        $this->load->library('form_validation');
        $this->load->library("session");
    }

    public function penalty($data)
    { //$data is the roomnumber

        echo link_tag('assets/css/form.css');
        $roomtype = $this->booking_mod->check($data);

        foreach ($roomtype as $key) {
            $key->Roomtype;
        }

        $roomtype = $key->Roomtype;

        $dits = array('roomnumber' => $data, 'roomtype' => $roomtype); //roomnumber and roomtype will be the variable that will be used to in the fpenalty view
        $this->load->view('booking/payment_form/fpenalty', $dits); // roomnumber and roomtype will be passed to the fpenalty view
    }

    public function book_process()
    {
        $this->form_validation->set_rules('firstname', 'Firstname', 'trim|required');
        $this->form_validation->set_rules('lastname', 'Lastname', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required');
        $this->form_validation->set_rules('numAdults', 'numadults', 'trim|required');
        $this->form_validation->set_rules('numKids', 'numkids', 'trim|required');
        $this->form_validation->set_rules('pay', 'Pay', 'trim|required');
        $this->form_validation->set_rules('Credit-Debit', 'credit-debit', 'trim|required');
        $this->form_validation->set_rules('fullname', 'Fullname', 'trim|required');
        $this->form_validation->set_rules('checkinDate', 'checkindate', 'trim|required');
        $this->form_validation->set_rules('checkoutDate', 'checkoutdate', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            //$this->load->view('mainpage/login');        
        } else {

            $firstname = $this->input->post('firstname');
            $lastname = $this->input->post('lastname');
            $email = $this->input->post('email');

            $adults = $this->input->post('numAdults');
            $children = $this->input->post('numKids');
            $guests = $adults + $children;

            $payment = $this->input->post('pay');
            $cardnumber = $this->input->post('Credit-Debit');
            $roomtype = $this->input->post('roomtype');
            $checkin = $this->input->post('checkinDate');
            $checkout = $this->input->post('checkoutDate');
            //$session = $this->signin_mod->user_check($user_email,$user_pass); //check sa db kung tama yung credentials na nilagay sa siginup form

            //this if for setting the price of the penalty
            $dayDifference = floor((strtotime($checkout) - strtotime($checkin)) / (60 * 60 * 24));
            $penalty = 0.0;
            if ($dayDifference >= 2 or $dayDifference >= 3)
                $penalty = .20;
            elseif ($dayDifference >= 4)
                $penalty = .15;
            elseif ($dayDifference > 5)
                $penalty = .10;
            // end of setting the price of the penalty

            //making the transcation id
            $transactionID = (strtoupper(substr($firstname, 0, 1)) .
                strtoupper(substr($lastname, 0, 1)) .
                strtoupper(date_format(date_create($checkin), "Md")) .
                date_format(date_create($checkin), "m") .
                substr(date_format(date_create($checkin), "Y"), -2) .
                "-" .
                strtoupper(substr($roomtype, 0, 3)) .
                sprintf("%05d", $guests)
            );
            //end of making transcation id

            $roomNo = 0;
            $price = 0;
            if ($roomtype == "KIN") :
                $roomNo = 101;
                $price = 2000;
            endif;
            if ($roomtype == "EXE") :
                $roomNo = 201;
                $price = 3000;
            endif;
            if ($roomtype == "PRE") :
                $roomNo = 301;
                $price = 4000;
            endif;
            if ($roomtype == "CAB") :
                $roomNo = 401;
                $price = 5000;
            endif;
            if ($roomtype == "VIL") :
                $roomNo = 501;
                $price = 6000;
            endif;
            if ($roomtype == "CON") :
                $roomNo = 601;
                $price = 7000;
            endif;


            $price = $price * $dayDifference; //price depending on how long the user will be staying 

            //this will check if the a room is occupied if it is then roomNo will increment
            runQueryCommand:
            $data = $this->booking_mod->check_room($roomNo);
            $row_cnt = $data;
            if ($row_cnt > 0) {
                ++$roomNo;
                goto runQueryCommand;
            } else {

                $GuestId = $this->session->userdata('loggedIn')['GuestId'];
                $details = array(
                    'TransactionID' => $transactionID,
                    'GuestID' => $GuestId,
                    'Roomtype' => $roomtype,
                    'Roomnumber' => $roomNo,
                    'Reservations' => $guests,
                    'Checkin' => $checkin,
                    'Checkout' => $checkout,
                    'Price' => $price,
                    'Stats' => 'PENDING',
                    'ModeOfPayment' => $payment,
                    'Cardnumber' => $cardnumber,
                    'Penalty' => $penalty,
                );

                $data = $this->booking_mod->reservation($details);
                $session = $this->booking_mod->show_reservations($GuestId);

                $sess_array = array(
                    'Transaction_ID' => $session[0]->TransactionID,
                    'Room_Status' => $session[0]->Stats,
                    'Room_type' => $session[0]->Roomtype,
                    'Room_Number' => $session[0]->Roomnumber,
                    'Check_In' => $session[0]->Checkin,
                    'Cardnumber' => $session[0]->Cardnumber,
                    'Price' => $session[0]->Price,
                    'Penalty' => $session[0]->Penalty,
                    'Status' => $session[0]->Stats,
                    'Check_Out' => $session[0]->Checkout,
                );

                $this->session->set_userdata('BookedIn', $sess_array);
                redirect('Account/show_account');
            }
        }
    }
    public function cancel_booking()
    {
        $roomnumber = $this->input->post('roomnumber');
        $roomtype = $this->input->post('roomtype');

        //echo $roomtype;
        $this->booking_mod->cancel_booking($roomnumber, $roomtype);
        redirect('Account/show_account');
    }
}
