<?php

class Logout extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->database();
        $this->load->library("session");

    }

    public function signout()
    {
        $this->session->sess_destroy();
        redirect('/Homepage/index');
    }
}