<?php

class Forgotpass extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->database();
        $this->load->model('acc_mod');
        $this->load->library('form_validation');
        $this->load->library("session");
        $this->load->helper('html');
    }

    public function changepass_form()
    {
        $this->load->view('user_acc/forgotpass');
    }

    public function changepass()
    {
        $this->form_validation->set_rules('email', 'Email', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');
        $this->form_validation->set_rules('confpass', 'Password confirmation ', 'required|matches[password]');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            $this->load->view('user_acc/forgotpass');
        } else {

            $user_email = $this->input->post('email');
            $user_pass = $this->input->post('password');
            $capsule = array('Password' => $user_pass);
            $session = $this->acc_mod->show_row_acc($user_email);

            if (count($session) > 0) {
                $this->acc_mod->changepass($user_email, $capsule);
                    $this->load->view('mainpage/login');
            } 
                elseif ($this->session->userdata('usr_email') == false) {
                    $_SESSION['usr_acc'] = "Email isn't connected to an account ";
                    $this->session->mark_as_flash('usr_acc');
                    $this->load->view('user_acc/forgotpass');
                }
            
        }
    }
}
